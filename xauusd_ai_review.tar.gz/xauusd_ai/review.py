from datetime import datetime, timezone, timedelta
import json
import pandas as pd
from .notify import send_telegram

HORIZON_BARS=3

def settle_pending(store, candles, settings):
    """Score each paper signal after three fully closed candles; also score the opposite side."""
    if len(candles) < HORIZON_BARS+2: return 0
    done=0
    for ts,side,confidence,entry,reason,version in store.pending_signals('15min'):
        try:
            t=pd.Timestamp(ts)
            later=candles.loc[candles.index > t]
            if len(later) < HORIZON_BARS: continue
            exit_price=float(later.iloc[HORIZON_BARS-1].close)
            if entry <= 0: continue
            cost=(settings.spread_points+settings.slippage_points)/float(entry)
            raw=exit_price/float(entry)-1
            buy=raw-cost; sell=-raw-cost
            net=buy if side=='BUY' else sell
            outcome='WIN' if net>0 else 'LOSS'
            review=(f'{side} was correct' if net>0 else f'{side} was wrong; '
                    f"{'BUY' if buy>sell else 'SELL'} would have performed better")
            now=datetime.now(timezone.utc).isoformat()
            store.save_review((ts,'15min',version,side,float(confidence),float(entry),exit_price,
                               net,outcome,now,buy,sell,review))
            msg=(f"XAUUSD SIGNAL REVIEW — {outcome}\nOriginal: {side} | confidence {float(confidence):.1%}\n"
                 f'Entry: {float(entry):.2f} | Exit after {HORIZON_BARS} candles: {exit_price:.2f}\n'
                 f'Net paper result: {net*100:.3f}% (costs estimated)\n'
                 f'If BUY: {buy*100:.3f}% | If SELL: {sell*100:.3f}%\n'
                 f'Review: {review}. Logged for model evaluation; no real trade was placed.')
            send_telegram(settings.telegram_token,settings.telegram_chat_id,msg)
            done+=1
        except Exception as exc:
            print('Signal review error:',ts,repr(exc))
    return done

def daily_report(store, settings, report_date=None):
    day=report_date or datetime.now(timezone.utc).date().isoformat()
    with store.connect() as c:
        rows=c.execute('''SELECT direction,confidence,net_return,outcome,buy_return,sell_return
          FROM signal_reviews WHERE substr(ts,1,10)=? AND interval='15min' ''',(day,)).fetchall()
        total=c.execute("SELECT COUNT(*) FROM signals WHERE substr(ts,1,10)=? AND interval='15min'",(day,)).fetchone()[0]
    if not rows:
        body=f'XAUUSD DAILY REVIEW — {day}\nSignals sent: {total}\nNo matured signal outcomes available yet.'
    else:
        wins=sum(r[3]=='WIN' for r in rows); losses=len(rows)-wins
        avg=sum(r[2] for r in rows)/len(rows)
        buy_w=sum(r[0]=='BUY' and r[3]=='WIN' for r in rows); sell_w=sum(r[0]=='SELL' and r[3]=='WIN' for r in rows)
        best=sum(max(r[4],r[5]) for r in rows)/len(rows)
        body=(f'XAUUSD DAILY REVIEW — {day}\nSignals sent: {total} | evaluated: {len(rows)}\n'
              f'Wins: {wins} | losses: {losses} | win rate: {wins/len(rows):.1%}\n'
              f'Average net paper return: {avg*100:.3f}% per signal\n'
              f'BUY wins: {buy_w} | SELL wins: {sell_w}\n'
              f'Average best-side hindsight return: {best*100:.3f}% (diagnostic only)\n'
              'The hindsight comparison is not available to the live model; it is used to study missed direction calls.')
    with store.connect() as c:
        c.execute('INSERT OR REPLACE INTO daily_reports VALUES (?,?,?)',(day,datetime.now(timezone.utc).isoformat(),body))
    send_telegram(settings.telegram_token,settings.telegram_chat_id,body)
    return body

def retrain_rolling_month(store, settings):
    """Train only on the most recent 30 days; save model only after enough observations."""
    from .model import Predictor
    from .backtest import evaluate_chronological
    candles=store.load_candles('15min',days=30)
    if len(candles)<700:
        return {'skipped':True,'reason':f'Only {len(candles)} 15m candles in the rolling month; need at least 700.'}
    predictor=Predictor(settings.model_path)
    result=predictor.train(candles,'15min',horizon=HORIZON_BARS)
    store.log_model(result['version'],'15min',result['train_rows'],result['test_rows'],result['metrics'])
    return result


def adaptive_confidence_floor(store, base_confidence):
    """Conservative feedback loop based on matured paper outcomes; requires a real sample."""
    with store.connect() as c:
        rows = c.execute("""SELECT direction, outcome FROM signal_reviews
            WHERE interval='15min' AND evaluated_at >= datetime('now','-30 days')""").fetchall()
    if len(rows) < 20:
        return float(base_confidence), f"feedback sample too small ({len(rows)}/20); base threshold retained"
    by_side = {}
    for side in ('BUY', 'SELL'):
        sample = [r[1] for r in rows if r[0] == side]
        if len(sample) >= 10:
            by_side[side] = sum(x == 'WIN' for x in sample) / len(sample)
    if by_side and max(by_side.values()) < 0.45:
        value = min(0.70, float(base_confidence) + 0.03)
        return value, f"recent paper win rates weak {by_side}; threshold tightened"
    if len(rows) >= 30 and by_side and max(by_side.values()) >= 0.60:
        value = max(0.50, float(base_confidence) - 0.01)
        return value, f"recent paper results supportive {by_side}; threshold eased slightly"
    return float(base_confidence), f"recent paper feedback {by_side}; base threshold retained"
