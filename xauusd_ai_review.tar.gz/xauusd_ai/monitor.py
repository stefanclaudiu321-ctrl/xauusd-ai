import time
from datetime import datetime, timezone
from .data import provider_from_settings
from .model import Predictor
from .signals import decide
from .notify import send_telegram
from .review import settle_pending, daily_report, retrain_rolling_month, adaptive_confidence_floor
from .rules import evaluate_rules
from .multi_timeframe import analyse_timeframes, confluence_for_side


def run_monitor(settings, store, poll_seconds=None):
    provider = provider_from_settings(settings)
    predictor = Predictor(settings.model_path)
    if predictor.pipeline is None:
        raise RuntimeError('Train a model first using at least 30 days of 15min history: python -m xauusd_ai.cli fetch --interval 15min --outputsize 3000')
    poll_seconds = poll_seconds or settings.poll_seconds
    last_bar = last_report_date = last_retrain_date = None
    last_m5_fetch = 0
    m5_cache = None
    while True:
        try:
            # 15m history supplies the rolling-month ML dataset and higher-timeframe context.
            bars = provider.fetch('15min', outputsize=3000)
            store.save_candles(bars, '15min')
            # M5 is refreshed less often to limit data-provider calls; it is used for entry timing.
            if m5_cache is None or time.time() - last_m5_fetch >= 300:
                m5_cache = provider.fetch('5min', outputsize=3000)
                store.save_candles(m5_cache, '5min')
                last_m5_fetch = time.time()
            closed = bars.iloc[:-1] if len(bars) > 1 else bars
            if len(closed) < 250:
                time.sleep(poll_seconds)
                continue
            settle_pending(store, closed, settings)
            now = datetime.now(timezone.utc)
            day = now.date().isoformat()
            if now.hour == 23 and now.minute >= 55 and last_report_date != day:
                daily_report(store, settings, day)
                last_report_date = day
            if now.hour == 0 and now.minute >= 15 and last_retrain_date != day:
                result = retrain_rolling_month(store, settings)
                print('Daily rolling retrain:', result)
                if not result.get('skipped'):
                    predictor = Predictor(settings.model_path)
                    send_telegram(settings.telegram_token, settings.telegram_chat_id,
                        f"XAUUSD daily model refresh. Version: {result['version']}\n"
                        f"Train rows: {result['train_rows']} | test rows: {result['test_rows']}\n"
                        "Research model only; no live orders.")
                last_retrain_date = day

            ts, probs, price = predictor.predict_latest(closed)
            if str(ts) == last_bar:
                time.sleep(poll_seconds)
                continue
            last_bar = str(ts)
            effective_floor, feedback_note = adaptive_confidence_floor(store, settings.min_confidence)
            side, confidence, reason = decide(probs, effective_floor)
            context = analyse_timeframes(m5_cache, bars)
            context_lines = [f"{tf}: {v['bias']}" + (f" (RSI {v['rsi']:.0f}, ADX {v['adx']:.0f})" if 'rsi' in v else "")
                             for tf, v in context.items()]
            if side != 'HOLD':
                rule_score, rule_total, rule_hits = evaluate_rules(closed, side)
                ratio, aligned, available, opposing = confluence_for_side(context, side)
                # Moderate policy: do not force a daily quota; require a technical baseline and
                # at least 45% weighted timeframe alignment, while exposing conflicts in alerts.
                if rule_score < 2 or ratio < 0.45:
                    print('Candidate held by confluence:', side, rule_score, ratio, context_lines)
                    time.sleep(poll_seconds)
                    continue
                msg = (f'XAUUSD {side} SIGNAL — PAPER RESEARCH\nPrice: {price:.2f}\n'
                       f"Probabilities: BUY {probs.get('BUY',0):.1%} | SELL {probs.get('SELL',0):.1%} | HOLD {probs.get('HOLD',0):.1%}\n"
                       f'Confidence: {confidence:.1%}\nRule confluence: {rule_score}/{rule_total} ({", ".join(rule_hits)})\n'
                       f'Multi-timeframe alignment: {aligned}/{available} weighted ({ratio:.0%}); opposing weight: {opposing}\n'
                       + '\n'.join(context_lines) + '\n'
                       'Signal timeframe: M15 | review after 3 closed M15 candles (~45 min)\n'
                       f'Adaptive feedback: {feedback_note}\nReason: {reason}\nNo real trade was placed.')
                inserted = store.save_signal(ts, '15min', side, confidence, price, reason, predictor.version)
                if inserted:
                    send_telegram(settings.telegram_token, settings.telegram_chat_id, msg)
                    store.save_prediction(ts, '15min', side, probs.get('BUY', 0), probs.get('SELL', 0), predictor.version)
            print(datetime.now(timezone.utc).isoformat(), side, probs, context_lines)
        except Exception as e:
            print('Monitor error:', repr(e))
        time.sleep(poll_seconds)
