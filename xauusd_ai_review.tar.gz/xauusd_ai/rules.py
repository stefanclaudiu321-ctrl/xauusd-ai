from .features import add_indicators
from .data import resample_ohlcv

def evaluate_rules(candles, side):
    """Transparent technical confluence checks; these are filters/context, not guarantees."""
    x=add_indicators(candles).dropna()
    if len(x)<5: return 0,5,['insufficient indicator history']
    r=x.iloc[-1]
    checks=[]
    if side=='BUY':
        checks.append(('EMA20 above EMA50',r.ema_20>r.ema_50))
        checks.append(('price above EMA20',r.close>r.ema_20))
        checks.append(('MACD above signal',r.macd>r.macd_signal))
        checks.append(('RSI bullish zone',50<r.rsi_14<70))
    else:
        checks.append(('EMA20 below EMA50',r.ema_20<r.ema_50))
        checks.append(('price below EMA20',r.close<r.ema_20))
        checks.append(('MACD below signal',r.macd<r.macd_signal))
        checks.append(('RSI bearish zone',30<r.rsi_14<50))
    checks.append(('ADX trend strength',r.adx_14>=18))
    score=sum(bool(ok) for _,ok in checks)
    return score,len(checks),[name for name,ok in checks if ok]
