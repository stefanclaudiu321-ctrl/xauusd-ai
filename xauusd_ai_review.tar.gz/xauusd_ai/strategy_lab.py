import itertools
from datetime import datetime, timezone
import json
import pandas as pd
from .backtest import evaluate_chronological

def run_experiments(candles, store, timeframe="15min"):
    # Small, explicit research grid. All results are logged; no live strategy is auto-promoted.
    experiments=[]
    for confidence, spread in itertools.product([0.55,0.58,0.62,0.66],[0.20,0.30,0.50]):
        try:
            result=evaluate_chronological(candles,spread=spread,horizon=3,
                                          min_confidence=confidence)
            score=result.get("mean_net_return",-1.0)
            params={"min_confidence":confidence,"spread_assumption":spread}
            experiments.append((score,params,result))
            with store.connect() as c:
                c.execute("INSERT INTO experiments VALUES (?,?,?,?,?)",
                          (datetime.now(timezone.utc).isoformat(),"confidence_spread_grid",
                           json.dumps(params),score,json.dumps(result)))
        except Exception as e:
            experiments.append((-1.0,{"min_confidence":confidence,"spread":spread},
                                {"error":str(e)}))
    return sorted(experiments,key=lambda x:x[0],reverse=True)
