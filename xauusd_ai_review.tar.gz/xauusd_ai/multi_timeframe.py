"""Multi-timeframe market context built only from fully closed candles."""
from .features import add_indicators
from .data import resample_ohlcv

TIMEFRAME_RULES = {
    "M5": ("5min", "5min"),
    "M15": ("15min", "15min"),
    "M30": ("30min", "30min"),
    "H1": ("1h", "1h"),
    "H4": ("4h", "4h"),
    "D1": ("1day", "1D"),
}


def _bias(df):
    if df is None or len(df) < 30:
        return {"bias": "UNKNOWN", "score": 0, "detail": "insufficient closed candles"}
    x = add_indicators(df).dropna(subset=["ema_20", "ema_50", "rsi_14", "macd", "macd_signal", "adx_14"])
    if x.empty:
        return {"bias": "UNKNOWN", "score": 0, "detail": "indicators unavailable"}
    r = x.iloc[-1]
    checks = [
        ("EMA20/EMA50", r.ema_20 > r.ema_50),
        ("price/EMA20", r.close > r.ema_20),
        ("MACD", r.macd > r.macd_signal),
        ("RSI", 50 < r.rsi_14 < 72),
    ]
    bull = sum(bool(v) for _, v in checks)
    bear_checks = [
        ("EMA20/EMA50", r.ema_20 < r.ema_50),
        ("price/EMA20", r.close < r.ema_20),
        ("MACD", r.macd < r.macd_signal),
        ("RSI", 28 < r.rsi_14 < 50),
    ]
    bear = sum(bool(v) for _, v in bear_checks)
    if bull >= 3 and bull > bear:
        bias, score, hits = "BULLISH", bull, [n for n, v in checks if v]
    elif bear >= 3 and bear > bull:
        bias, score, hits = "BEARISH", bear, [n for n, v in bear_checks if v]
    else:
        bias, score, hits = "NEUTRAL", max(bull, bear), []
    return {"bias": bias, "score": score, "detail": ", ".join(hits),
            "close": float(r.close), "rsi": float(r.rsi_14),
            "adx": float(r.adx_14), "atr": float(r.atr_14)}


def analyse_timeframes(m5, m15):
    """Return aligned M5/M15/M30/H1/H4/D1 bias. Inputs must be sorted OHLCV."""
    frames = {"M5": m5, "M15": m15}
    for label, rule in [("M30", "30min"), ("H1", "1h"), ("H4", "4h"), ("D1", "1D")]:
        frames[label] = resample_ohlcv(m15, rule)
    # Exclude the current, potentially incomplete candle from every timeframe.
    result = {}
    for label, frame in frames.items():
        closed = frame.iloc[:-1] if len(frame) > 1 else frame.iloc[0:0]
        result[label] = _bias(closed)
    return result


def confluence_for_side(context, side):
    desired = "BULLISH" if side == "BUY" else "BEARISH"
    weights = {"M5": 1, "M15": 2, "M30": 2, "H1": 3, "H4": 3, "D1": 2}
    available = sum(weights[k] for k, v in context.items() if v["bias"] != "UNKNOWN")
    aligned = sum(weights[k] for k, v in context.items() if v["bias"] == desired)
    opposing = sum(weights[k] for k, v in context.items() if v["bias"] not in (desired, "NEUTRAL", "UNKNOWN"))
    ratio = aligned / available if available else 0.0
    return ratio, aligned, available, opposing
