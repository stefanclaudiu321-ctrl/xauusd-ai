import argparse
from .config import settings
from .db import Store
from .data import provider_from_settings, import_csv, resample_ohlcv
from .features import TIMEFRAMES
from .model import Predictor
from .backtest import evaluate_chronological
from .strategy_lab import run_experiments

def main():
    p=argparse.ArgumentParser("XAUUSD AI Monitor")
    sub=p.add_subparsers(dest="cmd",required=True)
    sub.add_parser("init")
    f=sub.add_parser("fetch"); f.add_argument("--interval",default="1min"); f.add_argument("--outputsize",type=int,default=5000)
    c=sub.add_parser("import-csv"); c.add_argument("path"); c.add_argument("--interval",default="1min")
    t=sub.add_parser("train"); t.add_argument("--timeframe",default="15min"); t.add_argument("--horizon",type=int,default=3)
    b=sub.add_parser("backtest"); b.add_argument("--timeframe",default="15min")
    e=sub.add_parser("experiment"); e.add_argument("--timeframe",default="15min")
    r=sub.add_parser("run"); r.add_argument("--poll-seconds",type=int,default=None)
    args=p.parse_args()
    store=Store(settings.db_path)
    if args.cmd=="init":
        print("Initialized database:",settings.db_path)
    elif args.cmd=="fetch":
        df=provider_from_settings(settings).fetch(args.interval,args.outputsize)
        store.save_candles(df,args.interval)
        if args.interval=="1min":
            for tf,rule in TIMEFRAMES.items(): store.save_candles(resample_ohlcv(df,rule),tf)
        print(f"Saved {len(df)} candles for {args.interval}")
    elif args.cmd=="import-csv":
        df=import_csv(args.path,args.interval); store.save_candles(df,args.interval)
        print(f"Imported {len(df)} candles.")
    elif args.cmd=="train":
        candles=store.load_candles(args.timeframe)
        result=Predictor(settings.model_path).train(candles,args.timeframe,args.horizon)
        store.log_model(result["version"],args.timeframe,result["train_rows"],result["test_rows"],result["metrics"])
        print(result)
    elif args.cmd=="backtest":
        print(evaluate_chronological(store.load_candles(args.timeframe),
              spread=settings.spread_points,slippage=settings.slippage_points))
    elif args.cmd=="experiment":
        results=run_experiments(store.load_candles(args.timeframe),store,args.timeframe)
        print(results[:5])
    elif args.cmd=="run":
        from .monitor import run_monitor
        run_monitor(settings,store,args.poll_seconds)

if __name__=="__main__": main()
