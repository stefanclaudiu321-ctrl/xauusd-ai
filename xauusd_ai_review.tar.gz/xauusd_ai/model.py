from pathlib import Path
from datetime import datetime, timezone
import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, classification_report
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from .features import make_dataset

LABELS={0:"SELL",1:"HOLD",2:"BUY"}

class Predictor:
    def __init__(self, model_path):
        self.path=Path(model_path)
        self.pipeline=None
        self.feature_names=None
        self.version="untrained"
        if self.path.exists():
            obj=joblib.load(self.path)
            self.pipeline=obj["pipeline"]; self.feature_names=obj["features"]
            self.version=obj["version"]

    def train(self, candles, timeframe="15min", horizon=3, threshold=0.0015):
        ds=make_dataset(candles,horizon,threshold)
        if len(ds)<500:
            raise ValueError(f"Need at least 500 clean labeled rows; currently have {len(ds)}.")
        features=[c for c in ds.columns if c not in ["target","future_return"]]
        X=ds[features]; y=ds.target.astype(int)
        split=int(len(ds)*0.75)
        Xtr,Xte=X.iloc[:split],X.iloc[split:]
        ytr,yte=y.iloc[:split],y.iloc[split:]
        pipe=Pipeline([
            ("imputer",SimpleImputer(strategy="median")),
            ("model",HistGradientBoostingClassifier(max_iter=180,max_leaf_nodes=15,
                       learning_rate=0.06,l2_regularization=2.0,random_state=42))
        ])
        pipe.fit(Xtr,ytr)
        pred=pipe.predict(Xte)
        metrics={"accuracy":float(accuracy_score(yte,pred)),
                 "balanced_accuracy":float(balanced_accuracy_score(yte,pred)),
                 "report":classification_report(yte,pred,output_dict=True,zero_division=0),
                 "test_start":str(Xte.index[0]),"test_end":str(Xte.index[-1])}
        self.version=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        self.pipeline=pipe; self.feature_names=features
        self.path.parent.mkdir(parents=True,exist_ok=True)
        joblib.dump({"pipeline":pipe,"features":features,"version":self.version},self.path)
        return {"version":self.version,"train_rows":len(Xtr),"test_rows":len(Xte),"metrics":metrics}

    def predict_latest(self, candles):
        if self.pipeline is None: raise RuntimeError("Model not trained. Run train first.")
        ds=make_dataset(candles,horizon=3)
        # For live prediction we need latest features, without requiring a future target.
        from .features import add_indicators
        f=add_indicators(candles).reindex(columns=self.feature_names)
        row=f.dropna().tail(1)
        if row.empty: raise ValueError("Not enough recent candles for indicators.")
        probs=self.pipeline.predict_proba(row)[0]
        classes=self.pipeline.named_steps["model"].classes_
        result={LABELS[int(k)]:float(v) for k,v in zip(classes,probs)}
        return row.index[-1], result, float(candles.close.iloc[-1])
