import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    provider: str = os.getenv("DATA_PROVIDER", "twelvedata")
    api_key: str = os.getenv("TWELVE_DATA_API_KEY", "")
    symbol: str = os.getenv("TWELVE_DATA_SYMBOL", "XAU/USD")
    db_path: str = os.getenv("DATABASE_PATH", "data/xauusd.sqlite3")
    model_path: str = os.getenv("MODEL_PATH", "models/xauusd_model.joblib")
    telegram_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")
    min_confidence: float = float(os.getenv("MIN_CONFIDENCE", "0.54"))
    poll_seconds: int = int(os.getenv("POLL_SECONDS", "60"))
    spread_points: float = float(os.getenv("SPREAD_POINTS", "0.30"))
    slippage_points: float = float(os.getenv("SLIPPAGE_POINTS", "0.05"))

settings = Settings()
