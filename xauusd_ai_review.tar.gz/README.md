# XAUUSD AI Monitor — multi-timeframe continuous paper-research build

The project monitors XAUUSD and sends research-only BUY/SELL alerts to Telegram. It does **not** place orders or manage a live account.

## Analysis coverage
- **M5, M15, M30, H1, H4 and D1 context**: EMA20/EMA50 trend, price relative to EMA20, MACD direction, RSI regime and ADX trend strength.
- M15 remains the ML signal/settlement timeframe. M5 is refreshed every five minutes for shorter-term entry context; M30/H1/H4/D1 are resampled from the M15 history.
- Every timeframe uses closed candles only. The current forming candle is excluded to reduce repainting/false confirmations.
- Directional confluence is weighted: H1/H4 have higher weight than M5. A candidate needs the base technical rule check and at least 45% weighted timeframe alignment. Conflicting timeframes are reported rather than hidden.
- The 30-day M15 history feeds the rolling research model. MTF context is not itself a claim of a guaranteed predictive edge.

## Continuous review and learning
- Polls market data, checks each newly closed M15 candle and sends eligible moderate-confidence paper alerts.
- Three signals per day is a **goal, not a quota**. It will not manufacture trades when filters do not align. Lowering filters solely to force three signals can materially reduce quality.
- Each signal is evaluated after three subsequent closed M15 candles (~45 minutes): estimated spread/slippage, net directional result, and counterfactual BUY/SELL results.
- Each matured result is sent to Telegram and saved in SQLite. Daily reports show win rate, BUY/SELL breakdown and net paper return. A conservative feedback loop reviews the last 30 days of matured paper outcomes and can tighten/ease the confidence floor only after a minimum sample; it does not blindly rewrite model weights after one loss.
- Attempts a rolling 30-day model retrain once per UTC day when enough labeled candles exist. Re-training is not automatically promoted as better; compare out-of-sample metrics and paper results.

## Data and operating limits
- Twelve Data symbol access, available intervals, output-size limits and API quotas depend on the account. The monitor requests 3,000 M15 candles and 3,000 M5 candles; verify your plan supports this.
- M30/H1/H4/D1 are resampled from M15 history, so the longer timeframe context is limited by the amount of M15 history available. For a stronger D1/H4 history, add a dedicated higher-timeframe historical backfill/provider.
- Spot XAU/USD data can differ from your broker's XAUUSD CFD quote. Configure realistic spread/slippage and compare candle timestamps/prices against the broker.
- The three-candle settlement is a fixed-horizon research label, not a broker-style TP/SL simulation. It does not fully model variable spreads, commissions, swaps, gaps, execution latency or intrabar stop/target ordering.
- Win rate cannot be guaranteed. Accuracy alone is insufficient; monitor expectancy, drawdown, sample size, calibration and out-of-sample results.

## Setup (Python 3.11 recommended)

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Add TWELVE_DATA_API_KEY, and optional Telegram bot token/chat ID.
python -m xauusd_ai.cli init
python -m xauusd_ai.cli fetch --interval 15min --outputsize 3000
python -m xauusd_ai.cli train --timeframe 15min
python -m xauusd_ai.cli backtest --timeframe 15min
python -m xauusd_ai.cli run --poll-seconds 60
```

Keep the computer/VPS running while monitoring is active. Watch provider rate limits and costs. Telegram credentials are optional; without them, messages are not delivered.

## Environment
- `TWELVE_DATA_API_KEY`: required.
- `TWELVE_DATA_SYMBOL`: defaults to `XAU/USD`.
- `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`: optional notifications.
- `MIN_CONFIDENCE`: default `0.54`.
- `POLL_SECONDS`: default `60`.
- `SPREAD_POINTS`, `SLIPPAGE_POINTS`: estimated costs for paper settlement.

This is a research prototype. Run it in paper mode for a substantial sample and validate broker-specific execution before considering any real-money use.
