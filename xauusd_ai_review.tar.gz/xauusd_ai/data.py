from abc import ABC, abstractmethod
from pathlib import Path
import requests
import pandas as pd

class MarketDataProvider(ABC):
    @abstractmethod
    def fetch(self, interval="1min", outputsize=5000) -> pd.DataFrame: ...

class TwelveDataProvider(MarketDataProvider):
    URL = "https://api.twelvedata.com/time_series"
    def __init__(self, api_key: str, symbol="XAU/USD"):
        if not api_key:
            raise ValueError("TWELVE_DATA_API_KEY is missing. Add it to .env.")
        self.api_key, self.symbol = api_key, symbol

    def fetch(self, interval="1min", outputsize=5000):
        params = {"symbol": self.symbol, "interval": interval,
                  "outputsize": outputsize, "apikey": self.api_key,
                  "format": "JSON", "timezone": "UTC"}
        r = requests.get(self.URL, params=params, timeout=30)
        r.raise_for_status()
        payload = r.json()
        if "values" not in payload:
            raise RuntimeError(f"Data provider error: {payload.get('message', payload)}")
        df = pd.DataFrame(payload["values"])
        df["datetime"] = pd.to_datetime(df["datetime"], utc=True)
        for col in ["open","high","low","close","volume"]:
            if col not in df: df[col] = 0.0
            df[col] = pd.to_numeric(df[col], errors="coerce")
        df = df.dropna(subset=["open","high","low","close"])
        return df.sort_values("datetime").set_index("datetime")[["open","high","low","close","volume"]]

def provider_from_settings(settings):
    if settings.provider.lower() == "twelvedata":
        return TwelveDataProvider(settings.api_key, settings.symbol)
    raise ValueError(f"Unsupported DATA_PROVIDER={settings.provider}")

def import_csv(path: str, interval: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"datetime","open","high","low","close"}
    if not required.issubset(df.columns):
        raise ValueError(f"CSV must contain columns: {sorted(required)}")
    if "volume" not in df: df["volume"] = 0.0
    df["datetime"] = pd.to_datetime(df["datetime"], utc=True)
    for col in ["open","high","low","close","volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df.dropna(subset=["open","high","low","close"]).sort_values("datetime").set_index("datetime")[
        ["open","high","low","close","volume"]]

def resample_ohlcv(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    return df.resample(rule).agg({"open":"first","high":"max","low":"min",
                                  "close":"last","volume":"sum"}).dropna(subset=["open","close"])
