import numpy as np
import pandas as pd

TIMEFRAMES = {"5min":"5min","15min":"15min","30min":"30min",
              "1h":"1h","4h":"4h","1day":"1D","1week":"1W"}

def rsi(s, period=14):
    delta=s.diff()
    up=delta.clip(lower=0).ewm(alpha=1/period, adjust=False).mean()
    down=(-delta.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs=up/down.replace(0,np.nan)
    return 100-(100/(1+rs))

def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    x=df.copy()
    c=x.close
    for n in [9,20,50,100,200]:
        x[f"ema_{n}"]=c.ewm(span=n,adjust=False).mean()
    x["rsi_14"]=rsi(c)
    fast=c.ewm(span=12,adjust=False).mean()
    slow=c.ewm(span=26,adjust=False).mean()
    x["macd"]=fast-slow
    x["macd_signal"]=x.macd.ewm(span=9,adjust=False).mean()
    mid=c.rolling(20).mean()
    sd=c.rolling(20).std()
    x["bb_width"]=(4*sd)/mid.replace(0,np.nan)
    tr=pd.concat([(x.high-x.low),(x.high-c.shift()).abs(),
                  (x.low-c.shift()).abs()],axis=1).max(axis=1)
    x["atr_14"]=tr.rolling(14).mean()
    plus_dm=x.high.diff()
    minus_dm=-x.low.diff()
    plus_dm=plus_dm.where((plus_dm>minus_dm)&(plus_dm>0),0.0)
    minus_dm=minus_dm.where((minus_dm>plus_dm)&(minus_dm>0),0.0)
    atr=tr.rolling(14).mean().replace(0,np.nan)
    pdi=100*plus_dm.ewm(alpha=1/14,adjust=False).mean()/atr
    mdi=100*minus_dm.ewm(alpha=1/14,adjust=False).mean()/atr
    x["adx_14"]=(100*(pdi-mdi).abs()/(pdi+mdi).replace(0,np.nan)).ewm(alpha=1/14,adjust=False).mean()
    x["return_1"]=c.pct_change()
    x["return_3"]=c.pct_change(3)
    x["return_12"]=c.pct_change(12)
    x["range_pct"]=(x.high-x.low)/c.replace(0,np.nan)
    x["body_pct"]=(c-x.open)/x.open.replace(0,np.nan)
    x["hour"]=x.index.hour
    x["dayofweek"]=x.index.dayofweek
    x["above_ema20"]=(c>x.ema_20).astype(int)
    x["above_ema50"]=(c>x.ema_50).astype(int)
    x["ema20_50_spread"]=(x.ema_20-x.ema_50)/c
    # Simple rolling support/resistance distance, using prior bars only.
    x["dist_prior_high"]=(x.high.rolling(20).max().shift(1)-c)/c
    x["dist_prior_low"]=(c-x.low.rolling(20).min().shift(1))/c
    return x.replace([np.inf,-np.inf],np.nan)

def make_dataset(df: pd.DataFrame, horizon=3, threshold=0.0015):
    x=add_indicators(df)
    future_return=x.close.shift(-horizon)/x.close-1
    # 3 classes: down / neutral / up. Threshold is configurable and must be tuned.
    y=pd.Series(1,index=x.index)
    y[future_return < -threshold]=0
    y[future_return > threshold]=2
    features=[c for c in x.columns if c not in ["open","high","low","close","volume"]]
    data=x[features].copy()
    data["target"]=y
    data["future_return"]=future_return
    return data.dropna()
