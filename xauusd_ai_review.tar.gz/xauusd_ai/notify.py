import requests

def send_telegram(token, chat_id, message):
    if not token or not chat_id: return False
    url=f"https://api.telegram.org/bot{token}/sendMessage"
    r=requests.post(url,data={"chat_id":chat_id,"text":message},timeout=20)
    r.raise_for_status()
    return True
