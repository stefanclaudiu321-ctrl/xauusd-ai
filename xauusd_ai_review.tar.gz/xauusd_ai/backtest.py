import numpy as np
import pandas as pd
from .features import make_dataset
from .model import LABELS

def evaluate_chronological(candles, spread=0.30, slippage=0.05, horizon=3,
                           threshold=0.0015, min_confidence=0.58):
    ds=make_dataset(candles,horizon,threshold)
    if len(ds)<500: raise ValueError("Need at least 500 labeled rows.")
    feats=[c for c in ds.columns if c not in ["target","future_return"]]
    split=int(len(ds)*0.75)
    from sklearn.pipeline import Pipeline
    from sklearn.impute import SimpleImputer
    from sklearn.ensemble import HistGradientBoostingClassifier
    pipe=Pipeline([("imputer",SimpleImputer(strategy="median")),
                   ("model",HistGradientBoostingClassifier(max_iter=180,max_leaf_nodes=15,
                    learning_rate=0.06,l2_regularization=2.0,random_state=42))])
    pipe.fit(ds[feats].iloc[:split],ds.target.iloc[:split])
    test=ds.iloc[split:].copy()
    probs=pipe.predict_proba(test[feats])
    classes=pipe.named_steps["model"].classes_
    rows=[]
    for i,(idx,row) in enumerate(test.iterrows()):
        p={LABELS[int(k)]:float(v) for k,v in zip(classes,probs[i])}
        side="BUY" if p.get("BUY",0)>p.get("SELL",0) else "SELL"
        conf=max(p.get("BUY",0),p.get("SELL",0))
        if conf<min_confidence or p.get("HOLD",0)>=conf: continue
        # Future return is from close at signal to close horizon bars later.
        gross=float(row.future_return)
        direction=1 if side=="BUY" else -1
        # Costs expressed in price units, converted to approximate return at entry.
        entry=float(candles.loc[idx].close)
        cost=(spread+slippage)/entry
        net=direction*gross-cost
        rows.append((idx,side,conf,net))
    if not rows: return {"signals":0,"message":"No signals passed the threshold."}
    r=pd.DataFrame(rows,columns=["time","side","confidence","net_return"]).set_index("time")
    equity=(1+r.net_return).cumprod()
    peak=equity.cummax()
    return {"signals":len(r),"win_rate":float((r.net_return>0).mean()),
            "mean_net_return":float(r.net_return.mean()),
            "total_return":float(equity.iloc[-1]-1),
            "max_drawdown":float((equity/peak-1).min())}
