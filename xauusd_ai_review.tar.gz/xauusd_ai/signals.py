def decide(probabilities, min_confidence=0.58):
    up=probabilities.get("BUY",0.0)
    down=probabilities.get("SELL",0.0)
    hold=probabilities.get("HOLD",0.0)
    best=max(up,down)
    if best < min_confidence or hold >= best:
        return "HOLD", best, "Insufficient directional edge or HOLD probability is dominant."
    side="BUY" if up>down else "SELL"
    return side,best,f"{side} probability={best:.3f}; HOLD={hold:.3f}. Estimate only, not certainty."
