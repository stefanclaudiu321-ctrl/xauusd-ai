import sqlite3
from pathlib import Path
import pandas as pd

class Store:
    def __init__(self, path: str):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.init()

    def connect(self):
        return sqlite3.connect(self.path)

    def init(self):
        with self.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS candles (
              ts TEXT NOT NULL, interval TEXT NOT NULL,
              open REAL, high REAL, low REAL, close REAL, volume REAL,
              PRIMARY KEY(ts, interval));
            CREATE TABLE IF NOT EXISTS predictions (
              ts TEXT NOT NULL, interval TEXT NOT NULL, direction TEXT,
              p_up REAL, p_down REAL, model_version TEXT, outcome TEXT,
              PRIMARY KEY(ts, interval, model_version));
            CREATE TABLE IF NOT EXISTS signals (
              ts TEXT NOT NULL, interval TEXT NOT NULL, direction TEXT,
              confidence REAL, entry REAL, reason TEXT);
            CREATE TABLE IF NOT EXISTS signal_reviews (
              ts TEXT NOT NULL, interval TEXT NOT NULL, model_version TEXT NOT NULL,
              direction TEXT NOT NULL, confidence REAL, entry REAL, exit REAL,
              net_return REAL, outcome TEXT, evaluated_at TEXT,
              buy_return REAL, sell_return REAL, review TEXT,
              PRIMARY KEY(ts, interval, model_version));
            CREATE TABLE IF NOT EXISTS experiments (
              created_at TEXT, name TEXT, params TEXT, score REAL, notes TEXT);
            CREATE TABLE IF NOT EXISTS model_runs (
              created_at TEXT, version TEXT, timeframe TEXT,
              train_rows INTEGER, test_rows INTEGER, metrics TEXT);
            CREATE TABLE IF NOT EXISTS daily_reports (
              report_date TEXT PRIMARY KEY, created_at TEXT, body TEXT);
            ''')
            cols={r[1] for r in c.execute('PRAGMA table_info(signals)').fetchall()}
            if 'model_version' not in cols: c.execute('ALTER TABLE signals ADD COLUMN model_version TEXT')

    def save_candles(self, df: pd.DataFrame, interval: str):
        if df.empty: return
        out=df.copy(); out['ts']=pd.to_datetime(out.index,utc=True).astype(str); out['interval']=interval
        out=out.reset_index(drop=True)[['ts','interval','open','high','low','close','volume']]
        with self.connect() as c:
            out.to_sql('_candles_tmp',c,if_exists='replace',index=False)
            c.execute('''INSERT OR REPLACE INTO candles SELECT ts,interval,open,high,low,close,volume FROM _candles_tmp''')
            c.execute('DROP TABLE _candles_tmp')

    def load_candles(self, interval: str, days=None) -> pd.DataFrame:
        query='SELECT ts,open,high,low,close,volume FROM candles WHERE interval=?'
        params=[interval]
        if days is not None:
            query += " AND ts >= datetime('now', ?)"; params.append(f'-{int(days)} days')
        query += ' ORDER BY ts'
        with self.connect() as c: df=pd.read_sql_query(query,c,params=params)
        if df.empty: return df
        df['ts']=pd.to_datetime(df.ts,utc=True)
        return df.set_index('ts')

    def save_signal(self, ts, interval, direction, confidence, entry, reason, version='unknown'):
        with self.connect() as c:
            cur=c.execute('INSERT OR IGNORE INTO signals(ts,interval,direction,confidence,entry,reason,model_version) VALUES (?,?,?,?,?,?,?)',
                      (str(ts),interval,direction,float(confidence),float(entry),reason,version))
            return cur.rowcount > 0

    def pending_signals(self, interval):
        with self.connect() as c:
            return c.execute('''SELECT s.ts,s.direction,s.confidence,s.entry,s.reason,COALESCE(s.model_version,'unknown')
              FROM signals s LEFT JOIN signal_reviews r ON s.ts=r.ts AND s.interval=r.interval AND COALESCE(s.model_version,'unknown')=r.model_version
              WHERE s.interval=? AND r.ts IS NULL ORDER BY s.ts''',(interval,)).fetchall()

    def save_review(self, values):
        with self.connect() as c:
            c.execute('''INSERT OR REPLACE INTO signal_reviews
              (ts,interval,model_version,direction,confidence,entry,exit,net_return,outcome,evaluated_at,buy_return,sell_return,review)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)''',values)

    def save_prediction(self, ts, interval, direction, up, down, version):
        with self.connect() as c:
            c.execute('INSERT OR REPLACE INTO predictions VALUES (?,?,?,?,?,?,NULL)',(str(ts),interval,direction,up,down,version))

    def log_model(self, version, timeframe, train_rows, test_rows, metrics):
        import json
        from datetime import datetime, timezone
        with self.connect() as c:
            c.execute('INSERT INTO model_runs VALUES (?,?,?,?,?,?)',(datetime.now(timezone.utc).isoformat(),version,timeframe,train_rows,test_rows,json.dumps(metrics)))
